/*
/home/linux2014/WJT_2016/C_EXE6
leetcode.cpp
g++ -g3 leetcode.cpp -o gleetcode_exe;./gleetcode_exe
gdb gleetcode_exe
*/
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<map>
//----------
using namespace std;
//------------
#define _SUCCESS_ 1
#define _FAIL_ 0
//-----------
typedef struct xIntArray
{
	int m_ncount;
	int* m_pa;
}IntArray,*PIntArray;
//--------------
int FileInput(FILE* infp,PIntArray parr)
{
	int iret=_FAIL_;
	if(infp!=NULL&&feof(infp)==0&&parr!=NULL)
	{
		int i;
		fscanf(infp,"%d",&(parr->m_ncount));
		if(parr->m_ncount<=0)
		{
#define _BUFFSIZE_ 30
			char buff[_BUFFSIZE_];
			snprintf(buff,_BUFFSIZE_,"\tparr->m_ncount=%d;error!!\n",parr->m_ncount);
			perror(buff);
			exit(1);
#undef _BUFFSIZE_
		}
		parr->m_pa=(int*)calloc(parr->m_ncount,sizeof(int));
		if(parr->m_pa==NULL)
		{
			perror("\tparr->m_pa==NULL;error!!\n");
			exit(1);
		}
		for(i=0;i<parr->m_ncount;i++)
			fscanf(infp,"%d",(parr->m_pa+i));
		iret=_SUCCESS_;
	}
	return iret;
}
//--------
int FileOutput(FILE* outfp,const PIntArray parr)
{
	int iret=_FAIL_;
	if(outfp!=NULL&&ferror(outfp)==0&&parr!=NULL&&parr->m_pa!=NULL)
	{
		int i;
		const int nline=5;
		for(i=0;i<parr->m_ncount;)
		{
			fprintf(outfp,"  %5d",parr->m_pa[i]);
			i++;
			if(i%nline==0)
				fprintf(outfp,"\n");
		}
		fprintf(outfp,"\n");
		iret=_SUCCESS_;
	}
	return iret;
}
//------------
/*
一个有序的int型数组pa有n个元素,给定一个正整数k，对数组pa内出现次数超过k的元素做一些删除操作，
使得每个元素的出现次数不超过k，并返回新数组的元素个数。
*/
int RemoveDuplications(int* pa,const int n,const int k)
{
	int i=0,j=0,nret=-1;
	if(pa!=NULL&&n>=k&&k>=1)
	{
		for(i=k,j=i;j<n;j++)
		{
			if(pa[i-k]!=pa[j])
			{
				pa[i]=pa[j];
				i++;
			}
		}
		nret=i;
	}
	return nret;
}
void Test_RemoveDuplications()
{
	char infname[]="inData.txt";
	int k=2;
	FILE* infp=fopen(infname,"r");
	if(infp==NULL)
	{
#define _BUFFSIZE_ 100
		char buff[_BUFFSIZE_];
		snprintf(buff, _BUFFSIZE_,"\tFail to open file:%s!!\n",infname);
		perror(buff);
		exit(1);
#undef  _BUFFSIZE_
	}
	IntArray intarr;
	memset(&intarr,0,sizeof(IntArray));
	int iret=FileInput(infp,&intarr);
	int nAfterRemove=RemoveDuplications(intarr.m_pa,intarr.m_ncount,k);
	intarr.m_ncount=nAfterRemove;
	printf("\tRemoveDuplications_Result:\n");
	iret=FileOutput(stdout,&intarr);
	if(intarr.m_pa!=NULL)
		free(intarr.m_pa);
	fclose(infp);
}
//-------------------
/*
给定一个由小到大有序的int型数组，元素可重复，做一次旋转，得到新数组，
从新数组内查找一个给定的值。
*/
int FindInRotateArray(const int target,const PIntArray parr)
{
	int iret=-1;
	if(parr!=NULL&&parr->m_pa!=NULL)
	{
		int istart,iend,imid;
		for(istart=0,iend=parr->m_ncount-1;istart<=iend;)
		{
			imid=(istart+iend)>>1;
			if(parr->m_pa[imid]==target)
			{
				iret=imid;
				break;
			}
			else if(parr->m_pa[imid]<parr->m_pa[istart])
			{
				if(target>=parr->m_pa[imid]&&target<=parr->m_pa[iend])
					istart=imid+1;
				else
					iend=imid-1;
			}
			else if(parr->m_pa[imid]>parr->m_pa[istart])
			{
				if(target<parr->m_pa[imid]&&target>=parr->m_pa[istart])
					iend=imid-1;
				else
					istart=imid+1;
			}
			else
				istart++;
		}
	}
	return iret;
}
//----
void Test_FindInRotateArray()
{
	char infname[]="inData2.txt";
	int target=10;
	FILE* infp=fopen(infname,"r");
	if(infp==NULL)
	{
#define _BUFFSIZE_ 100
		char buff[_BUFFSIZE_];
		snprintf(buff, _BUFFSIZE_,"\tFail to open file:%s!!\n",infname);
		perror(buff);
		exit(1);
#undef  _BUFFSIZE_
	}
	IntArray intarr;
	memset(&intarr,0,sizeof(IntArray));
	int iret=FileInput(infp,&intarr);
	iret=FindInRotateArray(target,&intarr);
	printf("\ttarget=%d;index=%d\n",target,iret);
	iret=FileOutput(stdout,&intarr);
	if(intarr.m_pa!=NULL)
		free(intarr.m_pa);
	fclose(infp);
}
//----------------
int main()
{
	Test_RemoveDuplications();
	Test_FindInRotateArray();
	return 0;
}
//--------------































